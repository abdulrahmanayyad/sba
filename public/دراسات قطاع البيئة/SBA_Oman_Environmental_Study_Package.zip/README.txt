SAMI BIN AYYAD GROUP – Oman Environmental Market Study Package
Contents:
1) SBA_Oman_Environmental_Market_Study_AR.docx – Arabic market study.
2) SBA_Oman_Environmental_Opportunity_Database.xlsx – opportunity database with 7 worksheets.
3) README.txt – package notes.

Tender and opportunity status assessed on 14 November 2026.
OQEP future opportunities are indicative only and do not guarantee a tender.
Nama tender document purchase and eligibility must be reconfirmed before participation.
No market size or contract value has been invented.
