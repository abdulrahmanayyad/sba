SAMI BIN AYYAD GROUP – Côte d’Ivoire Environmental Market Study Package
Contents:
1) SBA_Cote_dIvoire_Environmental_Market_Study_AR.docx – Arabic market study.
2) SBA_Cote_dIvoire_Environmental_Opportunity_Database.xlsx – opportunity database with 7 worksheets.
3) README.txt – package notes.

Assessment date: 14 November 2026.
VABICUI call deadline (9 October 2026) is closed.
PASEA tender CI-ONEP-567534-CW-RFB deadline is 27 November 2026; verify addenda and eligibility.
PPM dates are planned publication/opening dates, not proof of live tenders.
No unsupported market-size or contract-value estimates are asserted.
