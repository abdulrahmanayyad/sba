SAMI BIN AYYAD GROUP
حزمة دراسة السوق والفرص البيئية – إثيوبيا
الدراسة رقم 17 من 66 | تاريخ الرصد: 14 نوفمبر 2026

المحتويات:
- SBA_Ethiopia_Environmental_Market_Study_AR.docx
- SBA_Ethiopia_Environmental_Opportunity_Database.xlsx (7 أوراق)
- README_AR.txt

فرص عاجلة:
1) TotalEnergies REOI-441/26/GS/PUR: جمع ونقل وإتلاف/تدوير مخلفات خطرة وإلكترونية واختبارات effluent؛ الإغلاق 27 نوفمبر 2026 قبل 16:00. يشترط تصريح بيئي ساري ورخصة تجارية وVAT وTIN.
2) ESIA لممر Mieso–Dire Dawa: 23 نوفمبر 2026 حسب GetChereta؛ تحقق من ERA.
3) SNV PURE: حلول التبريد والتجفيف والـ bio-slurry؛ 16 نوفمبر 2026 حسب QELAL.
4) Plan International Sanitation Market Assessment: 17 نوفمبر حسب QELAL.

ملاحظة: بعض الفرص مستخرجة من منصات تجميع ويجب تأكيدها من الجهة. تشريعات 2025 المذكورة هي إعلان 1371/2025 للـ ESIA وإعلان 1383/2025 للنفايات الصلبة.
