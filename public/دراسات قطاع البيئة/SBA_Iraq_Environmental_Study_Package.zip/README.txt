SAMI BIN AYYAD GROUP – Iraq Environmental Market Study Package
Contents:
1) SBA_Iraq_Environmental_Market_Study_AR.docx – Arabic market study.
2) SBA_Iraq_Environmental_Opportunity_Database.xlsx – opportunity database with 7 worksheets.
3) README.txt – package notes.

Assessment date: 14 November 2026.
Tender statuses are distinguished from investment opportunities and planned projects.
EBS tender deadline must be reconfirmed on the bidder portal after registration.
AFD prequalification opportunities have demanding financial and experience requirements.
No unverified contract value or market size is asserted.
