SAMI BIN AYYAD GROUP – FOUR COUNTRY RECOVERY PACKAGE
Countries: Rwanda, Zambia, Egypt, Algeria
Each country has:
- Arabic Word market study
- Excel opportunity database with separate tabs for market summary, opportunities/projects, regulation, target accounts, services, 180-day plan and sources as applicable.

Research snapshot: 14 November 2026.
Important: Reconstructed export copies were generated from the indexed project content. Before submitting a tender, verify the latest buyer documents, dates, eligibility and local licensing. Aggregator listings are not treated as confirmed buyer tenders.
